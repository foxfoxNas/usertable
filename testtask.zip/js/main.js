const root = document.querySelector('#user-list-table');
const popUpBody = document.querySelector('.popUpBody');
const popup = document.querySelector('.popup');
const closepopup = document.querySelector('.closepopup');
const table = document.querySelector('.user-list');
const userList = document.querySelector('.user-list');
const formAddUser = document.querySelector('.form-add-user')
const formInputrs = formAddUser.querySelectorAll('input')



const Http = new XMLHttpRequest();
const url = 'https://jsonplaceholder.typicode.com/users';

Http.open("GET", url);
Http.send();

Http.onload = (e) => {
  let data = JSON.parse(Http.response);

  // init default users
  root.innerHTML = generateUsers(data);

  // add new user
  formAddUser.addEventListener('submit', e => {
    e.preventDefault();

    const formData = new FormData(e.target);

    // simpe validation :D
    if(formData.get('name').length < 4){
      return;
    }

    let newUser = {
      id: data.length + 1,
      name: formData.get('name'),
      username: formData.get('username'),
      email: formData.get('email'),
      website: formData.get('website'),
      address: {
        city: '',
        zipcode: '',
        street: ''
      }
    }
    data.push(newUser);
    root.innerHTML = generateUsers(data);



    // clear inputs
    for (input of formInputrs) {
      input.value = ''
    }



  })
  userList.addEventListener('click', e => {
    try {
      let rowIndex = e.target.offsetParent.parentElement.rowIndex - 1;
      let selectPerentElement = e.target.offsetParent.parentElement;

      switch (e.target.attributes.eventaction.value) {

        case 'DELETE_USER':
          data.splice(rowIndex, 1);
          selectPerentElement.remove();
          break;

        case 'GET_MORE_INFO':
          popUpBody.innerHTML = `${data[rowIndex]['name']}${data[rowIndex]['address']['city']} - ${data[rowIndex]['address']['zipcode']} - ${data[rowIndex]['address']['street']}`
          popup.classList.toggle('hidden')
          break;

        case 'SORT_BY_NAME':
          sortUsers('name')
          break;
        case 'SORT_BY_USERNAME':
          sortUsers('username')
          break;
        case 'SORT_BY_EMAIL':
          sortUsers('email')
          break;
        case 'SORT_BY_WEBSITE':
          sortUsers('website')
          break;

        default:
          break;
      }
    } catch (error) {
      console.log(error)
      return;
    }
  });
  closepopup.addEventListener('click', e => popup.classList.toggle('hidden'));
  popup.addEventListener('click', e => {
    if (e.target.classList.contains('hidden')) { popup.classList.toggle('hidden'); }
  })

  function sortUsers(propertry) {
    data = data.sort((a, b) => a[propertry] > b[propertry]);
    root.innerHTML = generateUsers(data);

  }
  function generateUsers(d) {
    let tempUsers = '';
    for (person of d) {
      let btnInfo = `<button eventAction='GET_MORE_INFO' class="btn-manipilation btn-more-info"></button>`
      let btnDelete = `<button eventAction='DELETE_USER' class="btn-manipilation btn-delete-user"></button>`
      tempUsers += `<tr><td>${person.name}</td><td id='${person.id}'>${person.username}</td><td>${person.email}</td><td>${person.website}</td><td>${btnInfo}${btnDelete}</td></tr>`
    }
    return tempUsers;

  }
}


